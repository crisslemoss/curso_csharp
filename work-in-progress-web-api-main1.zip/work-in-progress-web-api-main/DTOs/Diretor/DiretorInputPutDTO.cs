public class DiretorInputPutDTO {
     public string Nome { get; set; }
}