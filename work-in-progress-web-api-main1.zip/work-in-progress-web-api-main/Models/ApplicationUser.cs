using Microsoft.AspNetCore.Identity;

public class ApplicationUser : IdentityUser {

}